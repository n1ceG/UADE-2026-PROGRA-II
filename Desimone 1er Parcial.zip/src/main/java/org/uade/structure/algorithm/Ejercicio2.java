package org.uade.structure.algorithm;

import org.uade.structure.exception.EmptyADTException;
import org.uade.structure.implementation.dinamica.StackADTDynamic;
import org.uade.structure.implementation.estatica.LinkedListADTStatic;
import org.uade.structure.implementation.estatica.PriorityQueueADTStatic;

public class Ejercicio2 {
    PriorityQueueADTStatic cola1;
    PriorityQueueADTStatic cola2;

    public void main(){
        PriorityQueueADTStatic cola1 = new PriorityQueueADTStatic();
        PriorityQueueADTStatic cola2 = new PriorityQueueADTStatic();
        PriorityQueueADTStatic copia1 = copiar(cola1);
        PriorityQueueADTStatic copia2 = copiar(cola2);
        cola1.add(1, 3);
        cola1.add(5, 2);
        cola1.add(7, 5);

        consignaC(cola1);
    }

    private PriorityQueueADTStatic copiar(PriorityQueueADTStatic cola) {
        PriorityQueueADTStatic copia = new PriorityQueueADTStatic();
        PriorityQueueADTStatic aux = new PriorityQueueADTStatic();

        while (!cola.isEmpty()) {
            int valor = cola.getElement();
            int prio = cola.getPriority();
            cola.remove();
            aux.add(valor, prio);
        }

        while (!aux.isEmpty()) {
            int valor = aux.getElement();
            int prio = aux.getPriority();
            aux.remove();
            cola.add(valor, prio);
            copia.add(valor, prio);
        }
        return copia;
    }

    //PARTE DE CÓDIGO SIN TERMINAR
    private LinkedListADTStatic contador(PriorityQueueADTStatic cola) {
        LinkedListADTStatic elementos = new LinkedListADTStatic();
        LinkedListADTStatic cantidades = new LinkedListADTStatic();
        while(!cola.isEmpty()) {
            elementos.add(cola.getElement());
        }
    }

    public boolean consignaB(PriorityQueueADTStatic cola1, PriorityQueueADTStatic cola2) {
        int elemento1 = cola1.getElement();
        int elemento2 = cola2.getElement();
        while(!cola1.isEmpty() && !cola2.isEmpty()){

        }
        return
    }
    //PARTE DE CÓDIGO SIN TERMINAR


    public void consignaC(PriorityQueueADTStatic cola){
        if(cola.isEmpty()){
            throw new EmptyADTException("La pila está vacía.");
        }
        else{
            PriorityQueueADTStatic pilaAux = new PriorityQueueADTStatic();
            while(!cola.isEmpty()){
                pilaAux.add(cola.getElement(),  cola.getPriority());
                cola.remove();
            }
            while(!pilaAux.isEmpty()){
                cola.add(pilaAux.getElement(),   pilaAux.getPriority());
                System.out.println(pilaAux.getElement());
                pilaAux.remove();
            }
        }
    }
}
