package org.uade.structure.algorithm;

import org.uade.structure.exception.EmptyADTException;
import org.uade.structure.implementation.dinamica.QueueADTDynamic;
import org.uade.structure.implementation.dinamica.StackADTDynamic;


public class Ejercicio1 {
    // CONSIGNA GENERAL: Queremos transferir el contenido de una cola a una pila, pero solo si los elementos de la cola son pares.
    // Consigna B: Escriba un método que reciba ambas estructuras y retorne una pila con los valores filtrados.
    // Consigna C: Genere un método que muestre el contenido de la pila sin perderlo durante la operación.
    StackADTDynamic pila;
    QueueADTDynamic cola;

    public void main() {
        pila = new StackADTDynamic();
        cola =  new QueueADTDynamic();

        cola.add(1);
        cola.add(2);
        cola.add(3);
        cola.add(4);
        cola.add(5);
        cola.add(6);
        cola.add(7);
        cola.add(8);
        cola.add(9);
        cola.add(10);

        StackADTDynamic nuevaPila = consignaB(cola, pila);
        consignaC(nuevaPila);
    }

    public StackADTDynamic consignaB(QueueADTDynamic cola, StackADTDynamic pila) {
        if(cola.isEmpty()){
            throw new EmptyADTException("La cola está vacía");
        }else{
            QueueADTDynamic colaAux = new QueueADTDynamic();
            while(!cola.isEmpty()){
                int elemento = cola.getElement();
                if(elemento%2==0){
                    pila.add(elemento);
                }
                cola.remove();
            }
        }
        return pila;
    }

    public void consignaC(StackADTDynamic pila){
        if(pila.isEmpty()){
            throw new EmptyADTException("La pila está vacía.");
        }
        else{
            StackADTDynamic pilaAux = new StackADTDynamic();
            while(!pila.isEmpty()){
                pilaAux.add(pila.getElement());
                pila.remove();
            }
            while(!pilaAux.isEmpty()){
                pila.add(pilaAux.getElement());
                System.out.println(pilaAux.getElement());
                pilaAux.remove();
            }
        }
    }
}
