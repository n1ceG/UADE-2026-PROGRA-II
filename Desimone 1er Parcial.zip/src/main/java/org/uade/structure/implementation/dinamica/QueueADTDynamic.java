package org.uade.structure.implementation.dinamica;

import org.uade.structure.definition.QueueADT;
import org.uade.structure.exception.EmptyADTException;

public class QueueADTDynamic implements QueueADT {
    public Nodo first;
    public Nodo last;
    public QueueADTDynamic() {
        this.first = null;
        this.last = null;
    }

    @Override
    public void add(int value){
        Nodo nuevo = new Nodo(value);
        if(isEmpty()){
            first = nuevo;
            last = nuevo;
        }
        else{
            last.next = nuevo;
            last = nuevo;
        }
    }

    @Override
    public void remove(){
        if(isEmpty()){
            throw new EmptyADTException("La cola está vacía.");
        }
        first = first.next;
        if (first == null){ last = null; }
    }

    @Override
    public int getElement(){
        if(isEmpty()){
            throw new EmptyADTException("La cola está vacía.");
        }
        return first.value;
    }

    @Override
    public boolean isEmpty(){
        return first == null;
    }

    private QueueADTDynamic copy(){
        QueueADTDynamic copia = new QueueADTDynamic();
        QueueADTDynamic aux = new QueueADTDynamic();
        while(!this.isEmpty()){
            int value = this.getElement();
            this.remove();
            aux.add(value);
        }
        while(!aux.isEmpty()){
            int value = aux.getElement();
            aux.remove();
            this.add(value);
            copia.add(value);
        }
        return copia;
    }
}