package org.uade.structure.implementation.estatica;
import org.uade.structure.definition.LinkedListADT;
public class LinkedListADTStatic implements LinkedListADT {

    private int[] data;
    private int size;

    public LinkedListADTStatic(){
        this.data = new int[10]; // Por defecto 10 slots
        this.size = 0;
    }

    @Override
    public void add(int value){
        if(size == data.length){
            resize();
        }
        data[size] = value;
        size++;
    }
    @Override
    public void insert(int index, int value){
        if(index<0 || index>size){
            throw new IndexOutOfBoundsException("Índice inválido: "+index);
        }
        if (size == data.length){
            resize();
        }
        for (int i = size; i>index; i--){   // i = cantidad de cosas.
            data[i] = data[i-1];            // Arranca por uno más que el último elemento, y va corriendo 1 slot "a la derecha" a todos los que están entre el total y el índice.
        }
        data[index] = value;    // Inserta el valor en el índice
        size++;
    }

    @Override
    public void remove(int index){
        if (index<0 || index>size){
            throw new IndexOutOfBoundsException("Índice inválido: "+index);
        }
        for(int i = index; i<size-1; i++){
            data[i] = data[i+1];
        }
        size--;
    }

    @Override
    public int get(int index){
        if (index<0 || index>=size){
            throw new IndexOutOfBoundsException("Índice inválido: "+index);
        }
        return data[index];
    }

    @Override
    public int size(){
        return size;
    }

    @Override
    public boolean isEmpty(){
        return size == 0;
    }

    private void resize() {
        int[] newData = new int[data.length +10];
        for (int i = 0; i < size; i++) {
            newData[i] = data[i];
        }
        data = newData;
    }
}