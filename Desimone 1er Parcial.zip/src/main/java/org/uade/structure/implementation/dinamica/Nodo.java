package org.uade.structure.implementation.dinamica;

public class Nodo{
    public int value; // Valor almacenado del nodo
    public Nodo next; // Nodo al que este nodo apunta
    public int priority; // Sólo para PrioQueue

    public Nodo(int value){
        this.value = value;
        this.next = null;
        this.priority = 0;
    }

    public Nodo(int value, int priority){
        this.value = value;
        this.next = null;
        this.priority = priority;
    }
}