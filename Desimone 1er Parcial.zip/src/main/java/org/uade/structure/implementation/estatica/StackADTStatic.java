package org.uade.structure.implementation.estatica;

import org.uade.structure.definition.StackADT;
import org.uade.structure.exception.EmptyADTException;


public class StackADTStatic implements StackADT {
    private int[] data;
    private int top;

    public StackADTStatic() {
        this.data = new int[10];
        this.top = -1; //-1 para indicar que está vacía
    }
    @Override
    public void add(int value){
        if(top == data.length - 1){
            resize();
        }
        top++;
        data[top] = value;
    }
    @Override
    public void remove(){
        if(isEmpty()){
            throw new EmptyADTException("La pila está vacía.");
        }
        data[top] = 0;
        top--;
    }
    @Override
    public int getElement(){
        if(isEmpty()){
            throw new EmptyADTException("La pila está vacía.");
        }
        return data[top];
    }
    @Override
    public boolean isEmpty(){
        return top == -1;
    }

    private void resize(){
        int[] newData = new int[data.length + 10];
        int i = 0;
        while(i <=top){
            newData[i] = data[i];
            i++;
        }
        data = newData;
    }

    private StackADTStatic copiar() {
        StackADTStatic copia = new StackADTStatic();
        StackADTStatic temp = new StackADTStatic();

        while (!this.isEmpty()) {
            temp.add(this.getElement());
            this.remove();
        }

        while (!temp.isEmpty()) {
            int valor = temp.getElement();
            temp.remove();
            this.add(valor);
            copia.add(valor);
        }
        return copia;
    }
}