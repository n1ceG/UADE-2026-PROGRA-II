package org.uade.structure.implementation.estatica;

import org.uade.structure.definition.QueueADT;
import org.uade.structure.exception.EmptyADTException;

public class QueueADTStatic implements QueueADT {

    private int[] data;
    private int first;
    private int last;

    public QueueADTStatic() {
        this.data = new int[10];
        this.first = 0;
        this.last = -1;
    }

    @Override
    public void add(int value) {
        if (last == data.length - 1) {
            resize();
        }
        last++;
        data[last] = value;
    }

    @Override
    public void remove() {
        if (isEmpty()) {
            throw new EmptyADTException("La cola está vacía");
        }
        for (int i = first; i < last; i++) {
            data[i] = data[i + 1];
        }
        data[last] = 0;
        last--;
    }

    @Override
    public int getElement() {
        if (isEmpty()) {
            throw new EmptyADTException("La cola está vacía");
        }
        return data[first];
    }

    @Override
    public boolean isEmpty() {
        return first > last;
    }

    private void resize() {
        int[] newData = new int[data.length * 2];
        for (int i = first; i <= last; i++) {
            newData[i - first] = data[i];
        }
        data = newData;
        last = last - first;
        first = 0;
    }

    private QueueADT copy() {
        QueueADT copia = new QueueADTStatic();
        QueueADT aux = new QueueADTStatic();

        while (!this.isEmpty()) {
            int valor = this.getElement();
            this.remove();
            aux.add(valor);
        }

        while (!aux.isEmpty()) {
            int valor = aux.getElement();
            aux.remove();
            this.add(valor);
            copia.add(valor);
        }
        return copia;
    }
}