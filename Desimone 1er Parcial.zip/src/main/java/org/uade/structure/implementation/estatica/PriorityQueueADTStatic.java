package org.uade.structure.implementation.estatica;

import org.uade.structure.definition.PriorityQueueADT;
import org.uade.structure.exception.EmptyADTException;

public class PriorityQueueADTStatic implements PriorityQueueADT {

    private int[] values;
    private int[] priorities;
    private int first;
    private int last;
    private int capacity;

    public PriorityQueueADTStatic() {
        this.capacity = 10;
        this.values = new int[capacity];
        this.priorities = new int[capacity];
        this.first = 0;
        this.last = -1;
    }

    @Override
    public void add(int value, int priority) {
        if (last == capacity - 1) {
            resize();
        }

        int pos = first;
        while (pos <= last && priorities[pos] >= priority) {
            pos++;
        }

        int i = last;
        while (i >= pos) {
            values[i + 1] = values[i];
            priorities[i + 1] = priorities[i];
            i--;
        }

        values[pos] = value;
        priorities[pos] = priority;
        last++;
    }

    @Override
    public void remove() {
        if (isEmpty()) {
            throw new EmptyADTException("La cola con prioridad está vacía");
        }

        int i = first;
        while (i < last) {
            values[i] = values[i + 1];
            priorities[i] = priorities[i + 1];
            i++;
        }
        last--;
    }

    @Override
    public int getElement() {
        if (isEmpty()) {
            throw new EmptyADTException("La cola con prioridad está vacía");
        }
        return values[first];
    }

    @Override
    public int getPriority() {
        if (isEmpty()) {
            throw new EmptyADTException("La cola con prioridad está vacía");
        }
        return priorities[first];
    }

    @Override
    public boolean isEmpty() {
        return first > last;
    }

    private void resize() {
        int newCapacity = capacity * 2;
        int[] newValues = new int[newCapacity];
        int[] newPriorities = new int[newCapacity];

        int i = first;
        while (i <= last) {
            newValues[i - first] = values[i];
            newPriorities[i - first] = priorities[i];
            i++;
        }

        values = newValues;
        priorities = newPriorities;
        last = last - first;
        first = 0;
        capacity = newCapacity;
    }

    private void ordenarMayorAMenor() {
        if (isEmpty() || first == last) return; // 0 o 1 elemento

        PriorityQueueADT copia = this.copiar();
        PriorityQueueADT ordenada = new PriorityQueueADTStatic();

        // Extraemos todo (el orden de extracción + cómo se inserta en ordenada
        // garantiza que los empates de prioridad mantengan FIFO)
        while (!copia.isEmpty()) {
            int valor = copia.getElement();
            int prio = copia.getPriority();
            copia.remove();
            ordenada.add(valor, prio);
        }

        // Vaciamos la original
        while (!this.isEmpty()) {
            this.remove();
        }

        // Reinsertamos ya ordenados
        while (!ordenada.isEmpty()) {
            this.add(ordenada.getElement(), ordenada.getPriority());
            ordenada.remove();
        }
    }


    private void ordenarMenorAMayor() {
        if (isEmpty() || first == last) return;

        PriorityQueueADT copia = this.copiar();
        PriorityQueueADT ordenada = new PriorityQueueADTStatic();

        while (!copia.isEmpty()) {
            int valor = copia.getElement();
            int prio = copia.getPriority();
            copia.remove();
            ordenada.add(valor, prio);
        }


        PriorityQueueADT invertida = new PriorityQueueADTStatic();
        while (!ordenada.isEmpty()) {
            int valor = ordenada.getElement();
            int prio = ordenada.getPriority();
            ordenada.remove();
            invertida.add(valor, -prio);
        }


        while (!this.isEmpty()) {
            this.remove();
        }


        while (!invertida.isEmpty()) {
            int valor = invertida.getElement();
            int prio = invertida.getPriority();
            invertida.remove();
            this.add(valor, -prio);
        }
    }

    private void imprimir() {
        if (isEmpty()) {
            System.out.println("PriorityQueue vacía");
            return;
        }

        PriorityQueueADT copia = this.copiar();

        System.out.print("PriorityQueue [ ");
        while (!copia.isEmpty()) {
            int valor = copia.getElement();
            int prio = copia.getPriority();
            copia.remove();
            System.out.print("(" + valor + ", prio=" + prio + ") ");
        }
        System.out.println("]");
    }

    private PriorityQueueADT copiar() {
        PriorityQueueADT copia = new PriorityQueueADTStatic();
        PriorityQueueADT temp = new PriorityQueueADTStatic();

        while (!this.isEmpty()) {
            int valor = this.getElement();
            int prio = this.getPriority();
            this.remove();
            temp.add(valor, prio);
        }

        while (!temp.isEmpty()) {
            int valor = temp.getElement();
            int prio = temp.getPriority();
            temp.remove();
            this.add(valor, prio);
            copia.add(valor, prio);
        }
        return copia;
    }
}