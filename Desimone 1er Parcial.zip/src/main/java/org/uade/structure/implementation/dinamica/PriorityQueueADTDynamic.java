package org.uade.structure.implementation.dinamica;

import org.uade.structure.definition.PriorityQueueADT;
import org.uade.structure.exception.EmptyADTException;

public class PriorityQueueADTDynamic implements PriorityQueueADT {

    private Nodo head;

    public PriorityQueueADTDynamic() {
        this.head = null;
    }

    @Override
    public void add(int value, int priority) {
        Nodo nuevo = new Nodo(value, priority);

        if (head == null || head.priority < priority) {
            nuevo.next = head;
            head = nuevo;
        } else {
            Nodo actual = head;
            while (actual.next != null && actual.next.priority >= priority) {
                actual = actual.next;
            }
            nuevo.next = actual.next;
            actual.next = nuevo;
        }
    }

    @Override
    public void remove() {
        if (isEmpty()) {
            throw new EmptyADTException("La cola con prioridad está vacía");
        }
        head = head.next;
    }

    @Override
    public int getElement() {
        if (isEmpty()) {
            throw new EmptyADTException("La cola con prioridad está vacía");
        }
        return head.value;
    }

    @Override
    public int getPriority() {
        if (isEmpty()) {
            throw new EmptyADTException("La cola con prioridad está vacía");
        }
        return head.priority;
    }

    @Override
    public boolean isEmpty() {
        return head == null;
    }


    private void ordenarMayorAMenor() {
        if (isEmpty() || head.next == null) return;

        PriorityQueueADT copia = this.copiar();
        PriorityQueueADT ordenada = new PriorityQueueADTDynamic();

        while (!copia.isEmpty()) {
            int valor = copia.getElement();
            int prio = copia.getPriority();
            copia.remove();
            ordenada.add(valor, prio);
        }

        // Vaciamos la original
        while (!this.isEmpty()) {
            this.remove();
        }

        while (!ordenada.isEmpty()) {
            this.add(ordenada.getElement(), ordenada.getPriority());
            ordenada.remove();
        }
    }


    private void ordenarMenorAMayor() {
        if (isEmpty() || head.next == null) return;

        PriorityQueueADT copia = this.copiar();
        PriorityQueueADT ordenada = new PriorityQueueADTDynamic();

        while (!copia.isEmpty()) {
            int valor = copia.getElement();
            int prio = copia.getPriority();
            copia.remove();
            ordenada.add(valor, prio);
        }

        // Invertimos usando prioridad negativa
        PriorityQueueADT invertida = new PriorityQueueADTDynamic();
        while (!ordenada.isEmpty()) {
            int valor = ordenada.getElement();
            int prio = ordenada.getPriority();
            ordenada.remove();
            invertida.add(valor, -prio);
        }

        while (!this.isEmpty()) {
            this.remove();
        }

        while (!invertida.isEmpty()) {
            int valor = invertida.getElement();
            int prio = invertida.getPriority();
            invertida.remove();
            this.add(valor, -prio);
        }
    }

    private void imprimir() {
        if (isEmpty()) {
            System.out.println("PriorityQueue vacía");
            return;
        }

        PriorityQueueADT copia = this.copiar();

        System.out.print("PriorityQueue [ ");
        while (!copia.isEmpty()) {
            int valor = copia.getElement();
            int prio = copia.getPriority();
            copia.remove();
            System.out.print("(" + valor + ", prio=" + prio + ") ");
        }
        System.out.println("]");
    }

    private PriorityQueueADT copiar() {
        PriorityQueueADT copia = new PriorityQueueADTDynamic();
        PriorityQueueADT temp = new PriorityQueueADTDynamic();

        while (!this.isEmpty()) {
            int valor = this.getElement();
            int prio = this.getPriority();
            this.remove();
            temp.add(valor, prio);
        }

        while (!temp.isEmpty()) {
            int valor = temp.getElement();
            int prio = temp.getPriority();
            temp.remove();
            this.add(valor, prio);
            copia.add(valor, prio);
        }
        return copia;
    }
}