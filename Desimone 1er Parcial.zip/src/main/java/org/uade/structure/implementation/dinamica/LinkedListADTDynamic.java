package org.uade.structure.implementation.dinamica;

import org.uade.structure.definition.LinkedListADT;


public class LinkedListADTDynamic implements LinkedListADT {
    private Nodo head;
    private int size;

    public LinkedListADTDynamic(){
        this.head = null;
        this.size = 0;
    }
    @Override
    public void add(int value){
        Nodo nuevo = new Nodo(value);
        if(head == null){
            head = nuevo;
        } else  {
            Nodo actual = head;
            while(actual.next != null){
                actual = actual.next;
            }
            actual.next = nuevo;
        }
        size++;
    }
    @Override
    public void insert(int index, int value){
        if(index < 0 || index > size){
            throw new IndexOutOfBoundsException("Índice inválido: " + index);
        }
        Nodo nuevo = new Nodo(value);
        if(index==0){
            nuevo.next = head;
            head = nuevo;
        }
        else{
            Nodo actual = head;
            for(int i=0;i<index-1;i++){
                actual = actual.next; // Avanza hasta estar justo antes del elemento con el índice (index) original
            }
            nuevo.next = actual.next;
            actual.next = nuevo;
        }
        size++;
    }
    @Override
    public void remove(int index){
        if(index<0||index>=size){
            throw new IndexOutOfBoundsException("Índice inválido: " + index);
        }
        if(index==0){
            head = head.next;
        }else{
            Nodo actual = head;
            for(int i=0;i<index-1;i++){
                actual = actual.next;
            }
            actual.next = actual.next.next;
        }
        size--;
    }
    @Override
    public int get(int index) {
        if(index<0||index>=size){
            throw new IndexOutOfBoundsException("Índice inválido: " + index);
        }
        Nodo actual = head;
        for(int i=0;i<index;i++){
            actual = actual.next;
        }
        return actual.value;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }
}